bl_info = {
    "name": "Default Cube Addon",
    "blender": (3, 0, 0),
    "category": "Add Mesh",
    "author": "YOU",
    "version": (1, 0),
    "description": "Adds a cube named 'Default Cube'.",
}

import bpy

# Operator to add the cube
class MESH_OT_add_default_cube(bpy.types.Operator):
    bl_idname = "mesh.add_default_cube"
    bl_label = "Add Default Cube"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Add a cube
        bpy.ops.mesh.primitive_cube_add()
        # Rename the object
        obj = context.active_object
        obj.name = "Default Cube"
        return {'FINISHED'}

# Add it to Shift+A → Mesh menu
def menu_func(self, context):
    self.layout.operator(MESH_OT_add_default_cube.bl_idname, text="Default Cube")

# Register/unregister
def register():
    bpy.utils.register_class(MESH_OT_add_default_cube)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)

def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    bpy.utils.unregister_class(MESH_OT_add_default_cube)

if __name__ == "__main__":
    register()
